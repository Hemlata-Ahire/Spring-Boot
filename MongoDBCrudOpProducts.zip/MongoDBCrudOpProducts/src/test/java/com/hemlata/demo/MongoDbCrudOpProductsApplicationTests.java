package com.hemlata.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoDbCrudOpProductsApplicationTests {

	@Test
	void contextLoads() {
	}

}
